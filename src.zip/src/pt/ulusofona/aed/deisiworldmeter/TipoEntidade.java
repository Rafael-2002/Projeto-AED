package pt.ulusofona.aed.deisiworldmeter;

public enum TipoEntidade { PAIS, CIDADE, INPUT_INVALIDO};
